﻿using Microsoft.Azure.CognitiveServices.Vision.ComputerVision;
using Microsoft.Azure.CognitiveServices.Vision.ComputerVision.Models;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace ComputerVision
{
    class Program
    {
        static string subscriptionKey = "d497ae56a00e49d98b522d637329ebab";
        static string endpoint = "https://visionapp1000.cognitiveservices.azure.com/";
        static void Main(string[] args)
        {
            ReadImage().GetAwaiter().GetResult();

            Console.ReadLine();
        }

        public static async Task ReadImage()
        {
            ComputerVisionClient client =
      new ComputerVisionClient(new ApiKeyServiceClientCredentials(subscriptionKey))
      { Endpoint = endpoint };
            string imgurl = "https://appstore400012.blob.core.windows.net/app/img1.jpg";
            var textHeaders = await client.ReadAsync(imgurl, language: "en");

            string operationLocation = textHeaders.OperationLocation;
            Thread.Sleep(2000);

            const int numberOfCharsInOperationId = 36;
            string operationId = operationLocation.Substring(operationLocation.Length - numberOfCharsInOperationId);
            ReadOperationResult results;
            do
            {
                results = await client.GetReadResultAsync(Guid.Parse(operationId));
            }
            while ((results.Status == OperationStatusCodes.Running ||
       results.Status == OperationStatusCodes.NotStarted));

            
            Console.WriteLine();
            var textUrlFileResults = results.AnalyzeResult.ReadResults;
            foreach (ReadResult page in textUrlFileResults)
            {
                foreach (Line line in page.Lines)
                {
                    Console.WriteLine(line.Text);
                }
            }

        }
    }
}
