﻿using Azure.Storage.Blobs;
using System;
using System.IO;
using System.Threading.Tasks;

namespace BlobApp
{
    class Program
    {
        static string str_connection = "DefaultEndpointsProtocol=https;AccountName=newstore40000;AccountKey=p5TrF9F1eV7Mf/bBc5Y+8atKaBu4dnJzrElYeZl7qxUe9aqnmwbPUHgkdPKxQLbhuOUrcyXo6ghMOI1d7BbQiA==;EndpointSuffix=core.windows.net";
        static async Task Main()
        {
            BlobServiceClient blobServiceClient = new BlobServiceClient(str_connection);
            BlobContainerClient container_client = blobServiceClient.GetBlobContainerClient("data");

            BlobClient blob_client=container_client.GetBlobClient("sample.txt");
            using FileStream uploadFileStream = File.OpenRead("C:\\tmp\\sample.txt");
            await blob_client.UploadAsync(uploadFileStream, true);
            uploadFileStream.Close();
            Console.WriteLine("File uploaded");

            Console.WriteLine("Operation complete");
        }
    }
}
